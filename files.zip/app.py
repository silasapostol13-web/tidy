"""
tidy.app — Textual TUI for the tidy file organizer.
Run with: tidy [path]
"""

import sys
import click
from pathlib import Path
from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.containers import Vertical, Horizontal, Center, Container
from textual.widgets import Static, Button, Header, Footer, Label, ProgressBar, DataTable
from textual.reactive import reactive
from textual.binding import Binding
from textual import work

from tidy.engine import scan, execute, undo, format_size, Plan, CATEGORIES


# ── Mascot ────────────────────────────────────────────────────────────────────

MASCOT = """\
╭───────╮
│ ┏━━━┓ │
│ ┃ ▪ ┃ │
│ ┗━━━┛ │
╰───┬───╯
    │    \
"""

MASCOT_WORKING = """\
╭───────╮
│ ┏━━━┓ │
│ ┃ ◦ ┃ │
│ ┗━━━┛ │
╰───┬───╯
    │    \
"""

MASCOT_DONE = """\
╭───────╮
│ ┏━━━┓ │
│ ┃ ✓ ┃ │
│ ┗━━━┛ │
╰───┬───╯
    │    \
"""


# ── Stylesheet ────────────────────────────────────────────────────────────────

CSS = """\
Screen {
    background: $surface;
}

/* ── Home Screen ───────────────────────────────────── */

#home-container {
    align: center middle;
    width: 100%;
    height: 100%;
}

#home-inner {
    width: 60;
    height: auto;
    align: center middle;
    padding: 1 2;
}

.mascot {
    text-align: center;
    color: $accent;
    text-style: bold;
    width: 100%;
    margin-bottom: 1;
}

.brand-name {
    text-align: center;
    color: $text;
    text-style: bold;
    width: 100%;
}

.tagline {
    text-align: center;
    color: $text-muted;
    width: 100%;
    margin-bottom: 1;
}

.target-path {
    text-align: center;
    color: $accent;
    width: 100%;
    margin-bottom: 1;
    text-style: italic;
}

.home-buttons {
    align: center middle;
    width: 100%;
    height: auto;
    margin-top: 1;
}

.home-buttons Button {
    margin: 0 1;
    min-width: 16;
}

/* ── Preview Screen ────────────────────────────────── */

#preview-container {
    width: 100%;
    height: 100%;
    padding: 1 2;
}

.preview-header {
    dock: top;
    height: 3;
    width: 100%;
    padding: 0 1;
}

.preview-title {
    text-style: bold;
    color: $accent;
}

.summary-line {
    color: $text-muted;
}

#preview-table {
    height: 1fr;
    margin: 1 0;
}

.preview-footer {
    dock: bottom;
    height: 3;
    width: 100%;
    align: center middle;
}

.preview-footer Button {
    margin: 0 1;
    min-width: 14;
}

/* ── Progress Screen ───────────────────────────────── */

#progress-container {
    align: center middle;
    width: 100%;
    height: 100%;
}

#progress-inner {
    width: 56;
    height: auto;
    align: center middle;
    padding: 2 3;
}

.progress-mascot {
    text-align: center;
    color: $warning;
    text-style: bold;
    width: 100%;
    margin-bottom: 1;
}

.progress-status {
    text-align: center;
    color: $text;
    width: 100%;
    margin-bottom: 1;
}

.progress-file {
    text-align: center;
    color: $text-muted;
    width: 100%;
    height: 1;
    margin-bottom: 1;
}

#progress-bar {
    width: 100%;
    margin: 0 0 1 0;
}

/* ── Done Screen ───────────────────────────────────── */

#done-container {
    align: center middle;
    width: 100%;
    height: 100%;
}

#done-inner {
    width: 56;
    height: auto;
    align: center middle;
    padding: 2 3;
}

.done-mascot {
    text-align: center;
    color: $success;
    text-style: bold;
    width: 100%;
    margin-bottom: 1;
}

.done-title {
    text-align: center;
    text-style: bold;
    color: $text;
    width: 100%;
}

.done-summary {
    text-align: center;
    color: $text-muted;
    width: 100%;
    margin-bottom: 1;
}

.done-buttons {
    align: center middle;
    width: 100%;
    margin-top: 1;
}

.done-buttons Button {
    margin: 0 1;
    min-width: 14;
}

/* ── Empty State ───────────────────────────────────── */

.empty-state {
    text-align: center;
    color: $text-muted;
    width: 100%;
    margin-top: 2;
}
"""


# ── Home Screen ───────────────────────────────────────────────────────────────

class HomeScreen(Screen):

    BINDINGS = [
        Binding("s", "scan", "Scan"),
        Binding("u", "undo", "Undo Last"),
        Binding("q", "quit_app", "Quit"),
    ]

    def __init__(self, target: Path):
        super().__init__()
        self.target = target

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Center(id="home-container"):
            with Vertical(id="home-inner"):
                yield Static(MASCOT, classes="mascot")
                yield Static("t i d y", classes="brand-name")
                yield Static("clean up your downloads", classes="tagline")
                yield Static(f"→ {self.target}", classes="target-path")
                with Center(classes="home-buttons"):
                    yield Button("Scan", variant="primary", id="btn-scan")
                    yield Button("Undo Last", variant="default", id="btn-undo")
                    yield Button("Quit", variant="error", id="btn-quit")
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-scan":
            self.action_scan()
        elif event.button.id == "btn-undo":
            self.action_undo()
        elif event.button.id == "btn-quit":
            self.action_quit_app()

    def action_scan(self):
        plan = scan(self.target)
        if plan.total_files == 0:
            self.notify("Nothing to organize — folder is already tidy.", title="All clean")
        else:
            self.app.push_screen(PreviewScreen(plan))

    def action_undo(self):
        ok, fail = undo()
        if ok == 0 and fail == 0:
            self.notify("No tidy operations to undo.", title="Undo")
        elif fail == 0:
            self.notify(f"Restored {ok} file{'s' if ok != 1 else ''}.", title="Undo complete")
        else:
            self.notify(f"Restored {ok}, failed {fail}.", title="Undo partial", severity="warning")

    def action_quit_app(self):
        self.app.exit()


# ── Preview Screen ────────────────────────────────────────────────────────────

class PreviewScreen(Screen):

    BINDINGS = [
        Binding("enter", "confirm", "Organize"),
        Binding("escape", "go_back", "Back"),
    ]

    def __init__(self, plan: Plan):
        super().__init__()
        self.plan = plan

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Vertical(id="preview-container"):
            with Vertical(classes="preview-header"):
                yield Static(
                    f"  {self.plan.total_files} files → {self.plan.category_count} folders   "
                    f"({format_size(self.plan.total_size)} total)",
                    classes="preview-title",
                )
            yield DataTable(id="preview-table")
            with Center(classes="preview-footer"):
                yield Button("← Back", variant="default", id="btn-back")
                yield Button("Organize", variant="success", id="btn-go")
        yield Footer()

    def on_mount(self):
        table = self.query_one(DataTable)
        table.add_columns("Category", "Files", "Size", "Examples")
        table.cursor_type = "row"
        table.zebra_stripes = True

        for cat, items in sorted(self.plan.by_category.items()):
            count = len(items)
            size = format_size(sum(i.size for i in items))
            examples = ", ".join(i.name for i in items[:3])
            if count > 3:
                examples += f" (+{count - 3} more)"
            table.add_row(cat, str(count), size, examples)

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "btn-back":
            self.action_go_back()
        elif event.button.id == "btn-go":
            self.action_confirm()

    def action_confirm(self):
        self.app.push_screen(ProgressScreen(self.plan))

    def action_go_back(self):
        self.app.pop_screen()


# ── Progress Screen ───────────────────────────────────────────────────────────

class ProgressScreen(Screen):

    progress_pct = reactive(0.0)
    current_file = reactive("")
    status_text = reactive("Organizing…")

    def __init__(self, plan: Plan):
        super().__init__()
        self.plan = plan
        self.log: list[dict] = []

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Center(id="progress-container"):
            with Vertical(id="progress-inner"):
                yield Static(MASCOT_WORKING, classes="progress-mascot")
                yield Static(self.status_text, classes="progress-status", id="status")
                yield ProgressBar(total=100, show_eta=False, show_percentage=True, id="progress-bar")
                yield Static("", classes="progress-file", id="current-file")

    def on_mount(self):
        self.run_organize()

    @work(thread=True)
    def run_organize(self):
        def on_progress(done, total, name):
            self.progress_pct = (done / total) * 100 if total else 100
            self.current_file = name
            self.status_text = f"Moving {done}/{total}…"

        self.log = execute(self.plan, on_progress=on_progress)
        self.progress_pct = 100
        self.current_file = ""
        self.status_text = "Done"
        self.app.call_from_thread(self._finish)

    def _finish(self):
        ok = sum(1 for e in self.log if e.get("ok"))
        fail = sum(1 for e in self.log if not e.get("ok"))
        self.app.switch_screen(DoneScreen(ok, fail))

    def watch_progress_pct(self, value: float):
        try:
            bar = self.query_one("#progress-bar", ProgressBar)
            bar.update(progress=value)
        except Exception:
            pass

    def watch_current_file(self, value: str):
        try:
            label = self.query_one("#current-file", Static)
            display = value if len(value) < 44 else value[:20] + "…" + value[-20:]
            label.update(display)
        except Exception:
            pass

    def watch_status_text(self, value: str):
        try:
            label = self.query_one("#status", Static)
            label.update(value)
        except Exception:
            pass


# ── Done Screen ───────────────────────────────────────────────────────────────

class DoneScreen(Screen):

    BINDINGS = [
        Binding("u", "undo_now", "Undo"),
        Binding("q", "quit_app", "Quit"),
        Binding("enter", "go_home", "Home"),
    ]

    def __init__(self, ok: int, fail: int):
        super().__init__()
        self.ok = ok
        self.fail = fail

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Center(id="done-container"):
            with Vertical(id="done-inner"):
                yield Static(MASCOT_DONE, classes="done-mascot")
                yield Static("All tidy.", classes="done-title")
                summary = f"{self.ok} file{'s' if self.ok != 1 else ''} organized"
                if self.fail:
                    summary += f" · {self.fail} failed"
                yield Static(summary, classes="done-summary")
                yield Static("Rollback log saved to ~/.tidy/", classes="done-summary")
                with Center(classes="done-buttons"):
                    yield Button("Undo", variant="warning", id="btn-undo")
                    yield Button("Home", variant="default", id="btn-home")
                    yield Button("Quit", variant="primary", id="btn-quit")
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "btn-undo":
            self.action_undo_now()
        elif event.button.id == "btn-home":
            self.action_go_home()
        elif event.button.id == "btn-quit":
            self.action_quit_app()

    def action_undo_now(self):
        ok, fail = undo()
        if fail == 0:
            self.notify(f"Restored {ok} file{'s' if ok != 1 else ''}.", title="Undone")
        else:
            self.notify(f"Restored {ok}, failed {fail}.", title="Undo partial", severity="warning")
        self.action_go_home()

    def action_go_home(self):
        # Pop all screens back to home
        while len(self.app.screen_stack) > 1:
            self.app.pop_screen()

    def action_quit_app(self):
        self.app.exit()


# ── Main App ──────────────────────────────────────────────────────────────────

class TidyApp(App):
    """tidy — clean up your downloads."""

    TITLE = "tidy"
    CSS = CSS

    BINDINGS = [
        Binding("q", "quit", "Quit"),
    ]

    def __init__(self, target: Path):
        super().__init__()
        self.target = target

    def on_mount(self):
        self.push_screen(HomeScreen(self.target))


# ── CLI Entry Point ───────────────────────────────────────────────────────────

@click.command()
@click.argument("path", default="~/Downloads", type=click.Path())
@click.option("--undo", is_flag=True, help="Undo the last tidy operation and exit.")
def main(path: str, undo: bool):
    """Tidy up a folder. Defaults to ~/Downloads."""
    target = Path(path).expanduser().resolve()

    if undo:
        from tidy.engine import undo as do_undo
        ok, fail = do_undo()
        if ok == 0 and fail == 0:
            click.echo("Nothing to undo.")
        elif fail == 0:
            click.echo(f"✓ Restored {ok} file{'s' if ok != 1 else ''}.")
        else:
            click.echo(f"Restored {ok}, failed to restore {fail}.")
        return

    if not target.exists():
        click.echo(f"Error: {target} does not exist.", err=True)
        sys.exit(1)
    if not target.is_dir():
        click.echo(f"Error: {target} is not a directory.", err=True)
        sys.exit(1)

    app = TidyApp(target)
    app.run()


if __name__ == "__main__":
    main()
