# tidy

A polished terminal file organizer. Scans your Downloads folder, sorts files by type, and lets you undo anything.

```
╭───────╮
│ ┏━━━┓ │
│ ┃ ▪ ┃ │
│ ┗━━━┛ │
╰───┬───╯
    │
```

## Install

```bash
pip install .
```

Or install in development mode:

```bash
pip install -e .
```

## Usage

```bash
tidy              # organizes ~/Downloads
tidy ~/Desktop    # organizes a specific folder
tidy --undo       # undo the last operation (no TUI)
```

Running `tidy` launches an interactive terminal UI where you can:

1. **Scan** your target folder
2. **Preview** what will be organized and where
3. **Confirm** and execute
4. **Undo** if you change your mind

## What it sorts

| Folder         | File types                                      |
|----------------|------------------------------------------------|
| PDFs           | `.pdf`                                          |
| Images         | `.png`, `.jpg`, `.gif`, `.svg`, `.webp`, etc.   |
| Documents      | `.doc`, `.docx`, `.txt`, `.md`, `.epub`, etc.   |
| Spreadsheets   | `.xls`, `.xlsx`, `.csv`, `.ods`, etc.           |
| Presentations  | `.ppt`, `.pptx`, `.key`, `.odp`                 |
| Videos         | `.mp4`, `.avi`, `.mkv`, `.mov`, etc.            |
| Audio          | `.mp3`, `.wav`, `.flac`, `.aac`, etc.           |
| Archives       | `.zip`, `.tar`, `.gz`, `.7z`, `.rar`, etc.      |
| Installers     | `.exe`, `.msi`, `.pkg`, `.dmg`, etc.            |
| Code           | `.py`, `.js`, `.ts`, `.html`, `.css`, etc.      |
| Fonts          | `.ttf`, `.otf`, `.woff`, `.woff2`               |
| Trash          | `.tmp`, `.crdownload`, `.DS_Store`, etc.        |
| Review         | Everything else                                 |

## Safety

- **Never overwrites files** — duplicates get a numbered suffix
- **Rollback logs** saved to `~/.tidy/` after every operation
- **Undo** from the TUI or with `tidy --undo`
- **Skips directories** in v1 to avoid risky bulk moves
- **Skips hidden files** (except known junk like `.DS_Store`)

## Requirements

- Python 3.10+
- Works on macOS, Linux, and Windows (any terminal that supports Unicode)

## License

MIT
