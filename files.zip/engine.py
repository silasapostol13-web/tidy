"""
tidy.engine — File scanning, categorization, moving, and rollback.
Pure logic, no UI. Operates on a target directory (defaults to ~/Downloads).
"""

import json
import shutil
from datetime import datetime
from pathlib import Path
from collections import defaultdict
from dataclasses import dataclass, field

# ── Category Definitions ─────────────────────────────────────────────────────

CATEGORIES: dict[str, set[str]] = {
    "PDFs":           {".pdf"},
    "Images":         {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".svg", ".webp",
                       ".ico", ".tiff", ".tif", ".heic", ".heif", ".avif"},
    "Documents":      {".doc", ".docx", ".txt", ".rtf", ".odt", ".md", ".tex",
                       ".pages", ".epub", ".mobi"},
    "Spreadsheets":   {".xls", ".xlsx", ".csv", ".tsv", ".ods", ".numbers"},
    "Presentations":  {".ppt", ".pptx", ".key", ".odp"},
    "Videos":         {".mp4", ".avi", ".mkv", ".mov", ".wmv", ".flv", ".webm",
                       ".m4v", ".mpg", ".mpeg", ".3gp"},
    "Audio":          {".mp3", ".wav", ".flac", ".aac", ".ogg", ".wma", ".m4a",
                       ".opus", ".aiff"},
    "Archives":       {".zip", ".tar", ".gz", ".bz2", ".7z", ".rar", ".xz",
                       ".zst", ".tgz"},
    "Installers":     {".exe", ".msi", ".pkg", ".deb", ".rpm", ".dmg", ".appimage"},
    "Code":           {".py", ".js", ".ts", ".jsx", ".tsx", ".html", ".css",
                       ".java", ".c", ".cpp", ".h", ".go", ".rs", ".rb",
                       ".php", ".swift", ".kt", ".sql", ".sh", ".ipynb"},
    "Fonts":          {".ttf", ".otf", ".woff", ".woff2"},
}

# Build reverse lookup: extension → category
_EXT_MAP: dict[str, str] = {}
for _cat, _exts in CATEGORIES.items():
    for _ext in _exts:
        _EXT_MAP[_ext] = _cat

JUNK_NAMES = {".ds_store", "thumbs.db", "desktop.ini"}
JUNK_EXTENSIONS = {".crdownload", ".part", ".tmp", ".temp", ".swp", ".bak"}

# Folders tidy creates — skip these when scanning
RESERVED_FOLDERS = set(CATEGORIES.keys()) | {"Review", "Trash"}

LOG_DIR = Path.home() / ".tidy"


@dataclass
class FileItem:
    path: Path
    name: str
    size: int  # bytes
    category: str


@dataclass
class Plan:
    """An organization plan: what will move where."""
    items: list[FileItem] = field(default_factory=list)
    target_dir: Path = field(default_factory=lambda: Path.home() / "Downloads")

    @property
    def by_category(self) -> dict[str, list[FileItem]]:
        groups: dict[str, list[FileItem]] = defaultdict(list)
        for item in self.items:
            groups[item.category].append(item)
        return dict(groups)

    @property
    def total_files(self) -> int:
        return len(self.items)

    @property
    def total_size(self) -> int:
        return sum(i.size for i in self.items)

    @property
    def category_count(self) -> int:
        return len(self.by_category)


def _safe_size(p: Path) -> int:
    try:
        return p.stat().st_size
    except OSError:
        return 0


def _classify(item: Path) -> str:
    """Classify a single file/dir into a category name."""
    name_lower = item.name.lower()

    # Junk detection
    if name_lower in JUNK_NAMES or item.suffix.lower() in JUNK_EXTENSIONS:
        return "Trash"

    # Directories → skip (we don't move dirs in v1 — too risky for a first ship)
    if item.is_dir():
        return "__skip__"

    # Extension-based lookup
    ext = item.suffix.lower()
    return _EXT_MAP.get(ext, "Review")


def scan(target_dir: Path) -> Plan:
    """Scan a directory and build an organization plan."""
    plan = Plan(target_dir=target_dir)

    if not target_dir.exists() or not target_dir.is_dir():
        return plan

    for item in sorted(target_dir.iterdir(), key=lambda p: p.name.lower()):
        # Skip hidden files (except known junk we want to trash)
        if item.name.startswith(".") and item.name.lower() not in JUNK_NAMES:
            continue

        # Skip folders tidy already created
        if item.is_dir() and item.name in RESERVED_FOLDERS:
            continue

        category = _classify(item)
        if category == "__skip__":
            continue

        plan.items.append(FileItem(
            path=item,
            name=item.name,
            size=_safe_size(item),
            category=category,
        ))

    return plan


def _safe_dest(dest: Path) -> Path:
    """Return a destination path that won't overwrite anything."""
    if not dest.exists():
        return dest
    stem = dest.stem
    suffix = dest.suffix
    parent = dest.parent
    counter = 1
    while True:
        candidate = parent / f"{stem} ({counter}){suffix}"
        if not candidate.exists():
            return candidate
        counter += 1


def execute(plan: Plan, on_progress=None) -> list[dict]:
    """
    Execute a plan. Moves files into category subfolders.
    Returns a move log (list of dicts with src/dst/category).
    Calls on_progress(done, total, filename) if provided.
    """
    log: list[dict] = []
    total = plan.total_files
    done = 0

    for item in plan.items:
        dest_dir = plan.target_dir / item.category
        dest_dir.mkdir(exist_ok=True)
        dst = _safe_dest(dest_dir / item.name)

        entry = {
            "src": str(item.path),
            "dst": str(dst),
            "category": item.category,
            "time": datetime.now().isoformat(),
        }

        try:
            shutil.move(str(item.path), str(dst))
            entry["ok"] = True
        except Exception as e:
            entry["ok"] = False
            entry["error"] = str(e)

        log.append(entry)
        done += 1
        if on_progress:
            on_progress(done, total, item.name)

    # Persist rollback log
    _save_log(log)
    return log


def _save_log(log: list[dict]):
    """Save a rollback log to ~/.tidy/"""
    LOG_DIR.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = LOG_DIR / f"tidy_{ts}.json"
    with open(path, "w") as f:
        json.dump(log, f, indent=2)


def get_last_log() -> list[dict] | None:
    """Load the most recent rollback log."""
    LOG_DIR.mkdir(exist_ok=True)
    logs = sorted(LOG_DIR.glob("tidy_*.json"), reverse=True)
    if not logs:
        return None
    with open(logs[0]) as f:
        return json.load(f)


def undo() -> tuple[int, int]:
    """
    Undo the most recent tidy operation.
    Returns (successful_undos, failed_undos).
    """
    log = get_last_log()
    if not log:
        return (0, 0)

    ok = 0
    fail = 0
    for entry in reversed(log):
        if not entry.get("ok"):
            continue
        src = Path(entry["dst"])  # current location
        dst = Path(entry["src"])  # original location
        try:
            if src.exists():
                shutil.move(str(src), str(dst))
                ok += 1
            else:
                fail += 1
        except Exception:
            fail += 1

    # Clean up empty category folders
    if log:
        target = Path(log[0]["src"]).parent
        for folder_name in RESERVED_FOLDERS:
            folder = target / folder_name
            if folder.is_dir() and not any(folder.iterdir()):
                folder.rmdir()

    # Remove the used log
    logs = sorted(LOG_DIR.glob("tidy_*.json"), reverse=True)
    if logs:
        logs[0].unlink(missing_ok=True)

    return (ok, fail)


def format_size(size_bytes: int) -> str:
    """Human-readable file size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024*1024):.1f} MB"
    else:
        return f"{size_bytes / (1024*1024*1024):.1f} GB"
